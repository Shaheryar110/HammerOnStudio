"use strict";
exports.id = 651;
exports.ids = [651];
exports.modules = {

/***/ 1030:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/1.2a95e65a.webp","height":460,"width":475,"blurDataURL":"data:image/webp;base64,UklGRloAAABXRUJQVlA4IE4AAADwAQCdASoIAAgAAkA4JQBOgCKUT+1I1AAA/uev/S4VIxzwUdFKSvkOgFckWcMqfoTW55oFmKSVnnhH9GGriBH4oFNnlm9+PN/JgnKUQAA=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 5730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/2.4080639d.webp","height":460,"width":475,"blurDataURL":"data:image/webp;base64,UklGRlQAAABXRUJQVlA4IEgAAADQAQCdASoIAAgAAkA4JQBOiP/wNtQMwAD92yjf260rnwwNdAaiLpxsyooN4OOhxMjUK3O5vBTQ2YEEAmyWog2raYASkSAAAAA=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 2295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/3.ef838be2.webp","height":460,"width":952,"blurDataURL":"data:image/webp;base64,UklGRkAAAABXRUJQVlA4IDQAAACwAQCdASoIAAQAAkA4JZwAAxPDPicQAP6+hOs3+ayoP48gd7zbBpUlX9HNz3PLfgEKeEAA","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 2269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/4.29ee565b.webp","height":460,"width":475,"blurDataURL":"data:image/webp;base64,UklGRlgAAABXRUJQVlA4IEwAAADQAQCdASoIAAgAAkA4JZgCdAEOZcRLgAD+4Kw4BsZYqUGcXq2EiKM2GcP8Ed4VxtVE0TQVTWaGksxsU/k4W5pr/UD5ITdvbrQiDAAA","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 1087:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/5.7036ecd7.webp","height":460,"width":475,"blurDataURL":"data:image/webp;base64,UklGRmYAAABXRUJQVlA4IFoAAADwAQCdASoIAAgAAkA4JYgCdAD0uMPtqwAA/grXFp39dbQSRn48vcsnA18QpW5xXU1ZJ9LS5twOf55XmFrABeqnAxVzR5JiXSfmES54KZcm41WzwHzOymAAAAA=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6309:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/6.fbe762b1.webp","height":460,"width":952,"blurDataURL":"data:image/webp;base64,UklGRlYAAABXRUJQVlA4IEoAAADQAQCdASoIAAQAAkA4JZgCdAD0gwVaAAD8IzGrHaON1BGOCPqE/b+o3hhUqCbHoW+7RDMXhOwmvPKJRiOyaEQEVXyRDsNeIwAAAA==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 5274:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function GalleryBox({ src, category, service }) {
    const style = {
        center: {
            justifyContent: "center",
            alignItems: "center"
        },
        margin: {
            marginY: "4rem"
        },
        navItem: {
            fontSize: "1.2rem",
            fontWeight: 600
        },
        ComName: {
            position: "relative",
            textAlign: "left",
            animation: "text-appear 1.2s linear forwards",
            animationDelay: "0.7s",
            fontWeight: 800,
            fontSize: "1.5rem",
            color: "white",
            marginBottom: "1rem",
            " :: before": {
                content: "' '",
                position: "absolute",
                backgroundColor: "rgb(238, 33, 43)",
                color: "#2871ae",
                width: "5px",
                height: "30px",
                left: "-8px"
            }
        },
        superText: {
            color: "white",
            fontSize: "1.1rem",
            marginY: "1rem"
        },
        gridIamge: {
            position: "relative",
            margin: "2px"
        },
        galleryOverlay: {
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            height: "100%",
            width: "100%",
            display: "flex",
            alignItems: "flex-end",
            backgroundColor: "rgb(0, 0, 0,0.5)",
            padding: "30px"
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        transition: {
            duration: 1
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
            sx: style.gridIamge,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                    src: src,
                    height: 300,
                    width: 300,
                    style: {
                        width: "100%",
                        height: "300px"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                    sx: style.galleryOverlay,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: style.superText,
                                children: category
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                variant: "h3",
                                sx: style.ComName,
                                children: service
                            })
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GalleryBox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6651:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_style_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7262);
/* harmony import */ var _styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_images_galleryImg_1_webp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1030);
/* harmony import */ var _assets_images_galleryImg_2_webp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5730);
/* harmony import */ var _assets_images_galleryImg_3_webp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2295);
/* harmony import */ var _assets_images_galleryImg_4_webp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2269);
/* harmony import */ var _assets_images_galleryImg_5_webp__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1087);
/* harmony import */ var _assets_images_galleryImg_6_webp__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6309);
/* harmony import */ var _Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5274);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__]);
_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













function Gallery({ border }) {
    const style = {
        center: {
            justifyContent: "center",
            alignItems: "center"
        },
        margin: {
            marginY: border ? "0px" : "4rem",
            paddingX: "0px",
            marginX: "0px"
        },
        navItem: {
            fontSize: "1.2rem",
            fontWeight: 600,
            cursor: "pointer"
        },
        ComName: {
            position: "relative",
            textAlign: "left",
            animation: "text-appear 1.2s linear forwards",
            animationDelay: "0.7s",
            fontWeight: 800,
            fontSize: "1.5rem",
            color: "white",
            " :: before": {
                content: "' '",
                position: "absolute",
                backgroundColor: "rgb(238, 33, 43)",
                color: "#2871ae",
                width: "5px",
                height: "30px",
                left: "-8px"
            }
        },
        superText: {
            color: "white",
            fontSize: "1.1rem"
        },
        gridIamge: {
            position: "relative",
            margin: "2px"
        },
        galleryOverlay: {
            position: "absolute",
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            height: "100%",
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            backgroundColor: "rgb(0, 0, 0,0.3)",
            padding: "30px"
        },
        borders: {
            borderTop: border ? "8px solid #3772B0" : "none",
            borderLeft: border ? "1rem solid #3772B0" : "none",
            borderRight: border ? "1rem solid #3772B0" : "none",
            borderBottom: border ? "1rem solid #3772B0" : "none"
        }
    };
    const [activeStatus, setActiveStatus] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("All Project");
    const onChangeHandler = (status)=>{
        setActiveStatus(status);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
            sx: style.margin,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
                sx: style.borders,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        sx: style.center,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            lg: 12,
                            sx: {
                                width: "100%",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                sx: {
                                    width: {
                                        lg: "60%",
                                        md: "100%"
                                    }
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                    className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().navTab),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>onChangeHandler("All Project"),
                                            className: activeStatus == "All Project" && (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().active),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                sx: style.navItem,
                                                children: "All Project"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            onClick: ()=>onChangeHandler("Factory"),
                                            children: [
                                                " ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                    className: activeStatus === "Factory" && (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().active),
                                                    sx: style.navItem,
                                                    children: "Factory"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>onChangeHandler("Residential"),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                className: activeStatus === "Residential" && (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().active),
                                                sx: style.navItem,
                                                children: "Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>onChangeHandler("Commercial"),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                className: activeStatus == "Commercial" && (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().active),
                                                sx: style.navItem,
                                                children: "Commercial"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            onClick: ()=>onChangeHandler("Interior"),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                className: activeStatus == "Interior" && (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().active),
                                                sx: style.navItem,
                                                children: "Interior"
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    }),
                    activeStatus === "All Project" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        sx: style.margin,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                sm: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_1_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                                category: "Factory,Residential",
                                                service: "Roof Construction"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_2_webp__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                                category: "Factory,Residential",
                                                service: "Roof Construction"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 12,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_6_webp__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                                category: "Factory,Residential",
                                                service: "Renovation Roof"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                sm: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 12,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_3_webp__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                                category: "Factory,Residential",
                                                service: "Modern Roofing"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_4_webp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                                service: "Classic Roofing",
                                                category: "Factory,Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_5_webp__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                                service: "Repair Roof",
                                                category: "Factory,Residential"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    activeStatus === "Factory" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        sx: style.margin,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_1_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                                service: "Roof Construction",
                                                category: "Factory,Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_2_webp__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                                service: "Roof Construction",
                                                category: "Factory,Residential"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    src: _assets_images_galleryImg_6_webp__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                    service: "Renovation Roof",
                                    category: "Factory,Residential"
                                })
                            })
                        ]
                    }),
                    activeStatus === "Residential" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        sx: style.margin,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 3,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_1_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                                service: "Roof Construction",
                                                category: "Factory,Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 6,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_3_webp__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                                service: "Modern Roofing",
                                                category: "Factory,Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 3,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_4_webp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                                service: "Roof Construction",
                                                category: "Factory,Residential"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 5,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_6_webp__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                                service: "Renovation Roof",
                                                category: "Factory,Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 3,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_5_webp__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                                service: "Repair Roof",
                                                category: "Factory,Residential"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    activeStatus === "Commercial" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        sx: style.margin,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 9,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                    container: true,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 4,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_1_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                                service: "Roof Construction",
                                                category: "Factory,Residential"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                            item: true,
                                            lg: 8,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                src: _assets_images_galleryImg_3_webp__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
                                                service: "Modern Roofing",
                                                category: "Factory,Residential"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    src: _assets_images_galleryImg_6_webp__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                    service: "Renovation Roof",
                                    category: "Factory,Residential"
                                })
                            })
                        ]
                    }),
                    activeStatus === "Interior" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        sx: style.margin,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            lg: 6,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                container: true,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                        item: true,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            src: _assets_images_galleryImg_4_webp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                            service: "Classic Roofing",
                                            category: "Factory,Residential"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                        item: true,
                                        lg: 6,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Commons_GalleryBox__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            src: _assets_images_galleryImg_5_webp__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                            category: "Factory,Residential",
                                            service: "Repair Roof"
                                        })
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Gallery);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;