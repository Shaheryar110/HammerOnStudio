exports.id = 760;
exports.ids = [760];
exports.modules = {

/***/ 1530:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/house.97f1d4de.webp","height":343,"width":456,"blurDataURL":"data:image/webp;base64,UklGRrgAAABXRUJQVlA4WAoAAAAQAAAABwAABQAAQUxQSDEAAAAAQf/59fD3SACu//7////nHYf//P//+/+wof/8//78///W///////70wuP6v3qkywAAFZQOCBgAAAA0AEAnQEqCAAGAAJAOCWwAnQA9KTGCcQAzj/dmEMZpguuUyz+LDrUkdg3gKNe4tsyOKwl8KAGubPwMA+fxVhPbCgUvQnsKfseL+7F87t/xt/xhPvdnmv+/2K+vtL27AAA","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 9255:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/new1.685ca0ad.webp","height":490,"width":398,"blurDataURL":"data:image/webp;base64,UklGRrIAAABXRUJQVlA4WAoAAAAQAAAABQAABwAAQUxQSDEAAAAAABz3UgADAB//aAAEAAv3bgAFE9P//74IN//9/90AMf///v87AsL//7AUAJn//4MAAFZQOCBaAAAA0AEAnQEqBgAIAAJAOCWYAnQA9LJWILgA/ooZw1ny2PN/WPh9+YRfvSmMi/sT29gqzHJCETGRr7Wlf4ypxeLB9UM53Dovmh3LJJSdH3Q6mHHIc6cQI/usUAAA","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 7520:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ ServiceGridSection)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/styles/style.module.css
var style_module = __webpack_require__(7262);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
// EXTERNAL MODULE: ./src/Components/Commons/BeforeHeadSmall.jsx
var BeforeHeadSmall = __webpack_require__(3485);
// EXTERNAL MODULE: ./src/Components/Commons/HeadingH2.jsx
var HeadingH2 = __webpack_require__(9749);
;// CONCATENATED MODULE: ./src/assets/images/labours.jpg
/* harmony default export */ const labours = ({"src":"/_next/static/media/labours.f2bd97bc.jpg","height":1836,"width":2560,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAYACAMBIgACEQEDEQH/xAAoAAEBAAAAAAAAAAAAAAAAAAAABwEBAQAAAAAAAAAAAAAAAAAAAAL/2gAMAwEAAhADEAAAAKGFf//EABsQAAMAAgMAAAAAAAAAAAAAAAECAwAiBBFh/9oACAEBAAE/ALSq8w1eQwRgNZ6ntvc//8QAGBEBAQEBAQAAAAAAAAAAAAAAAQIhAGH/2gAIAQIBAT8AIitZF93v/8QAGBEAAgMAAAAAAAAAAAAAAAAAAQIAETH/2gAIAQMBAT8ALMMNT//Z","blurWidth":8,"blurHeight":6});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/Components/Commons/ServiceGridSection.jsx









function Content({ smallHeading, mainHeading, para1, para2, src, order }) {
    const style = {
        sapcing: {
            marginY: "5rem",
            justifyContent: "space-between"
        },
        para: {
            marginY: "20px",
            color: "#817173",
            fontSize: "1rem"
        },
        rightSide: {}
    };
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Grid, {
                container: true,
                sx: style.sapcing,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Grid, {
                        item: true,
                        lg: 6,
                        style: {
                            order: order ? 2 : 1
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx(BeforeHeadSmall/* default */.Z, {
                                text: smallHeading
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(HeadingH2/* default */.Z, {
                                text: mainHeading
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                sx: style.para,
                                children: para1
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                sx: style.para,
                                children: para2
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(material_.Grid, {
                        item: true,
                        lg: 5,
                        style: {
                            order: order ? 1 : 2
                        },
                        children: /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: src,
                                fill: false,
                                style: {
                                    width: "100%",
                                    height: "100%"
                                },
                                className: (style_module_default()).imgs
                            })
                        })
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const ServiceGridSection = (Content);


/***/ }),

/***/ 5479:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _uri__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1592);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const postNewsLetterForm = async (data)=>{
    return await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`https://${_uri__WEBPACK_IMPORTED_MODULE_1__/* .URI */ .o}:5001/api/newsletter`, data);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (postNewsLetterForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1592:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   o: () => (/* binding */ URI)
/* harmony export */ });
const URI = "hammeronstudios.com";


/***/ }),

/***/ 3559:
/***/ (() => {



/***/ })

};
;