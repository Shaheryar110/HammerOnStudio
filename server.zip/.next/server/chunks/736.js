exports.id = 736;
exports.ids = [736];
exports.modules = {

/***/ 2104:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_607230', '__Inter_Fallback_607230'","fontStyle":"normal"},
	"className": "__className_607230"
};


/***/ }),

/***/ 9703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/tag01.ae4fa40c.webp","height":460,"width":475,"blurDataURL":"data:image/webp;base64,UklGRiYAAABXRUJQVlA4IBoAAAAwAQCdASoIAAgAAkA4JaQAA3AA/vroBAAAAA==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 9749:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_font_google_target_css_path_src_Components_Commons_HeadingH2_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2104);
/* harmony import */ var next_font_google_target_css_path_src_Components_Commons_HeadingH2_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_Components_Commons_HeadingH2_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




function HeadingH2({ text, align }) {
    const style = {
        styling: {
            fontWeight: "900",
            color: "#393738",
            textAlign: align || "left",
            fontSize: "37px",
            margin: "0px 0px 20px"
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        variant: "h3",
        sx: style.styling,
        className: (next_font_google_target_css_path_src_Components_Commons_HeadingH2_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_3___default().className),
        children: text
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeadingH2);


/***/ })

};
;