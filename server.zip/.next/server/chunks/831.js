exports.id = 831;
exports.ids = [831];
exports.modules = {

/***/ 463:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_8b1efc', '__Inter_Fallback_8b1efc'","fontStyle":"normal"},
	"className": "__className_8b1efc"
};


/***/ }),

/***/ 2437:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_8b1efc', '__Inter_Fallback_8b1efc'","fontStyle":"normal"},
	"className": "__className_8b1efc"
};


/***/ }),

/***/ 1410:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Poppins_0f5522', '__Poppins_Fallback_0f5522'","fontStyle":"normal"},
	"className": "__className_0f5522"
};


/***/ }),

/***/ 1733:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Poppins_cb35e5', '__Poppins_Fallback_cb35e5'","fontStyle":"normal"},
	"className": "__className_cb35e5"
};


/***/ }),

/***/ 1224:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_607230', '__Inter_Fallback_607230'","fontStyle":"normal"},
	"className": "__className_607230"
};


/***/ }),

/***/ 470:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_607230', '__Inter_Fallback_607230'","fontStyle":"normal"},
	"className": "__className_607230"
};


/***/ }),

/***/ 3129:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_8b1efc', '__Inter_Fallback_8b1efc'","fontStyle":"normal"},
	"className": "__className_8b1efc"
};


/***/ }),

/***/ 2161:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_607230', '__Inter_Fallback_607230'","fontStyle":"normal"},
	"className": "__className_607230"
};


/***/ }),

/***/ 3559:
/***/ (() => {



/***/ })

};
;