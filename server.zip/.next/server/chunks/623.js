exports.id = 623;
exports.ids = [623];
exports.modules = {

/***/ 5127:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "responsive_container__H_hoY"
};


/***/ }),

/***/ 7262:
/***/ ((module) => {

// Exports
module.exports = {
	"ul": "style_ul__45W6e",
	"li": "style_li__OdFSy",
	"lis": "style_lis__QH82G",
	"liImage": "style_liImage__TG4rv",
	"text": "style_text__JwGCk",
	"image": "style_image__b_9hU",
	"margin": "style_margin__p3xf_",
	"boxStyle": "style_boxStyle__SfIup",
	"size": "style_size__Wikps",
	"back": "style_back__4nPc_",
	"img1": "style_img1__5LzyR",
	"img2": "style_img2__HpWqU",
	"img3": "style_img3__rvX2Q",
	"contain": "style_contain__V0LkX",
	"h4": "style_h4__FMMz2",
	"h3": "style_h3__zIDhr",
	"par": "style_par__4WLbZ",
	"card": "style_card__PaD6M",
	"border": "style_border__AJ2g7",
	"cardInfo": "style_cardInfo__LE3tN",
	"fig": "style_fig__141Ae",
	"svg-content": "style_svg-content__fZyBt",
	"article": "style_article__3xEKo",
	"iconic": "style_iconic__gAhUR",
	"hThree": "style_hThree__GQGmi",
	"paragraph": "style_paragraph__h0ggi",
	"btn": "style_btn__n5cEy",
	"bgMain": "style_bgMain__5PX8h",
	"workTag": "style_workTag__NIoT2",
	"footer": "style_footer__s_nKa",
	"cta": "style_cta__C6tKH",
	"IconStyle": "style_IconStyle__t1LFU",
	"mediaBody": "style_mediaBody__rWj0o",
	"small": "style_small__KFYB3",
	"contact": "style_contact__GnGBI",
	"footSocial": "style_footSocial__yPW6P",
	"mediass": "style_mediass__iP85c",
	"span1": "style_span1___OtmQ",
	"mediaBod": "style_mediaBod__PZmam",
	"cardText": "style_cardText__fr4Zw",
	"cardContact": "style_cardContact__xPguG",
	"unOrderList": "style_unOrderList__2nt_2",
	"changeColor": "style_changeColor__63LxX",
	"feild": "style_feild__wR5N9",
	"feild1": "style_feild1__bKzza",
	"navTab": "style_navTab__gCeXP",
	"navItem": "style_navItem__f23Zh",
	"active": "style_active__NZmTF",
	"imgs": "style_imgs__Ww0gp",
	"feildC": "style_feildC__wnv6C",
	"cardBox": "style_cardBox__R0JFK",
	"cardBox1": "style_cardBox1__UrPs_",
	"cardImg": "style_cardImg__F49UG",
	"itemdate": "style_itemdate__O7ZQM",
	"cardContent": "style_cardContent__mBG76",
	"cardHeading": "style_cardHeading__j4Jig",
	"readMore": "style_readMore__nmv10",
	"readMore1": "style_readMore1___F_iQ",
	"dropDowmBox": "style_dropDowmBox__YWX29"
};


/***/ }),

/***/ 2679:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cas.5990e30e.webp","height":803,"width":1184,"blurDataURL":"data:image/webp;base64,UklGRpgAAABXRUJQVlA4WAoAAAAQAAAABwAABAAAQUxQSCkAAAAAAAAAQ6m9aAALDjydr+6xHz7e37ey6714AB6goKeNNQ4CADmOaRAAAABWUDggSAAAABACAJ0BKggABQACQDglsAJ0ugACuZT99QAA/tusN0sfZShTW+liZGOulgC3IMmf/HMkZTiC6V9Spf/xaIb9fj0v+IyL8QcAAA==","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 1991:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5127);
/* harmony import */ var _styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _styles_style_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7262);
/* harmony import */ var _styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_images_cas_webp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2679);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6872);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7666);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3281);
/* harmony import */ var _mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(303);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_10__]);
_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













function Footer() {
    const [isMouseInside, setIsMouseInside] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([
        false,
        false,
        false
    ]);
    const handleMouseEnter = (index)=>{
        setIsMouseInside((prev)=>{
            const updated = [
                ...prev
            ];
            updated[index] = true;
            return updated;
        });
    };
    const handleMouseLeave = (index)=>{
        setIsMouseInside((prev)=>{
            const updated = [
                ...prev
            ];
            updated[index] = false;
            return updated;
        });
    };
    const style = {
        flex: {
            display: "flex",
            marginTop: "2rem"
        },
        socialStyle: {
            width: "50px",
            height: "50px",
            backgroundColor: "#2E2F31",
            borderRadius: "5px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            ":hover": {
                backgroundColor: "white",
                transform: "scale(1.1)",
                transition: "all ease 0.5s"
            }
        },
        footerAlign: {
            justifyContent: {
                md: "space-between",
                xs: "center"
            },
            gap: {
                md: "0px",
                sm: "1rem",
                xs: "10px"
            }
        },
        small: {
            color: "white",
            fontWeight: 700,
            fontSize: "1.3rem"
        },
        contact: {
            color: "white",
            fontWeight: 700,
            fontSize: "1.3rem"
        },
        IconStyle: {
            backgroundColor: "#2296e6",
            width: "60px",
            height: "60px",
            alignItems: "center",
            display: "flex",
            borderRadius: "100%",
            color: "white",
            justifyContent: "center"
        },
        phoneIcon: {
            fontSize: "2rem"
        },
        copright: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginTop: "1rem"
        },
        page: {
            color: "white",
            ":hover": {
                color: "#3FBDF9",
                transition: "all ease 0.5s"
            }
        },
        page1: {
            color: "white",
            paddingX: "0.5rem",
            borderRight: "1px solid white",
            ":hover": {
                color: "#3FBDF9",
                transition: "all ease 0.5s",
                borderRight: "1px solid #3FBDF9"
            }
        },
        footerPage: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: "1rem"
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
            className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().footer),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                    sx: (_styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_12___default().container),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        container: true,
                        sx: style.footerAlign,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 2,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: _assets_images_cas_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                        width: 212,
                                        height: 144,
                                        style: {
                                            width: "212px",
                                            height: "144px"
                                        }
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 6,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().cta),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        sx: style.flex,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.IconStyle,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                    sx: style.phoneIcon
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().mediaBody),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                        sx: style.small,
                                                        children: "Need any renovation help?"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                        sx: style.contact,
                                                        children: "Contact Us: (845) 837-2616"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 2,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().footSocial),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                            href: "https://www.facebook.com/HammerOnStudios",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.socialStyle,
                                                onMouseEnter: ()=>handleMouseEnter(0),
                                                onMouseLeave: ()=>handleMouseLeave(0),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                    sx: {
                                                        color: isMouseInside[0] ? "#2296E6" : "white",
                                                        fontSize: "1.2rem"
                                                    }
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                            href: "https://www.instagram.com/hammeronstudiosllc/",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.socialStyle,
                                                onMouseEnter: ()=>handleMouseEnter(1),
                                                onMouseLeave: ()=>handleMouseLeave(1),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    sx: {
                                                        color: isMouseInside[1] ? "#2296E6" : "white",
                                                        fontSize: "1.2rem"
                                                    }
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                            href: "https://www.tiktok.com/@hammer.on.studios",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: [
                                                    style.socialStyle,
                                                    {
                                                        padding: "15px"
                                                    }
                                                ],
                                                onMouseEnter: ()=>handleMouseEnter(2),
                                                onMouseLeave: ()=>handleMouseLeave(2),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_9__.FontAwesomeIcon, {
                                                    icon: _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_10__.faTiktok,
                                                    fontSize: "sm",
                                                    color: isMouseInside[2] ? "#2296E6" : "white"
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                    sx: {
                        backgroundColor: "#242424",
                        marginY: "1rem"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                    sx: (_styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_12___default().container),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        sx: style.copright,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                sx: {
                                    color: "grey"
                                },
                                children: "\xa9 Copyright Hammer-On Studios 2022. All Right Reserved."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: style.footerPage,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        href: "/privacy-policy-2",
                                        style: {
                                            textDecoration: "none"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            sx: style.page1,
                                            children: "Privacy Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        href: "/terms-conditions",
                                        style: {
                                            textDecoration: "none"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            sx: style.page,
                                            children: "Terms & Condition"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9058:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6872);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Mail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9026);
/* harmony import */ var _mui_icons_material_Mail__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Mail__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7666);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3281);
/* harmony import */ var _mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Pinterest__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5941);
/* harmony import */ var _mui_icons_material_Pinterest__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Pinterest__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(303);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__]);
_fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const HeaderTop = ()=>{
    const style = {
        topHeader: {
            display: "flex",
            flexDirection: {
                lg: "row",
                sm: "column"
            },
            alignItems: "center",
            justifyContent: {
                lg: "space-between",
                sm: "center"
            },
            paddingY: {
                lg: "0px",
                sm: "2rem"
            }
        },
        iconStyle: {
            padding: "0.5rem",
            color: "#35A5F2",
            backgroundColor: "white",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        },
        topText: {
            fontSize: "15px",
            fontWeight: 600,
            lineHeight: "0.7em",
            marginBottom: "0.7rem"
        },
        topSecondText: {
            fontSize: "18px",
            fontWeight: 700,
            lineHeight: "0.7em"
        },
        boxDetail: {
            display: "flex",
            alignItems: "center",
            marginY: "1rem"
        },
        Left: {
            display: "flex",
            flexDirection: {
                lg: "row",
                xs: "column"
            },
            gap: {
                lg: "1rem"
            }
        },
        Left1: {
            display: "flex",
            flexDirection: "row",
            gap: "1rem"
        },
        icon: {
            color: "white",
            backgroundColor: "#35A5F2",
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            height: "40px",
            width: "40px"
        },
        container: {
            maxWidth: {
                lg: "1450px",
                md: "1000px"
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        bgcolor: "#1F588C",
        color: "primary.contrastText",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
            sx: style.container,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                sx: style.topHeader,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        sx: style.Left,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: style.boxDetail,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        mr: 1,
                                        sx: style.iconStyle,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_2___default()), {})
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                variant: "body2",
                                                sx: style.topText,
                                                children: "Need Any Roofing Help?"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                sx: style.topSecondText,
                                                children: "CALL US : (845) 837-2616"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: style.boxDetail,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        mr: 1,
                                        sx: style.iconStyle,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Mail__WEBPACK_IMPORTED_MODULE_3___default()), {})
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                variant: "body2",
                                                sx: style.topText,
                                                children: "Email Us:"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                sx: style.topSecondText,
                                                children: "info@hammeronstudios.com"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        sx: style.Left1,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                href: "https://www.facebook.com/HammerOnStudios",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    sx: style.icon,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_4___default()), {})
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                href: "https://www.instagram.com/hammeronstudiosllc/",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    sx: style.icon,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5___default()), {})
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                href: "https://www.tiktok.com/@hammer.on.studios",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    sx: [
                                        style.icon,
                                        {
                                            padding: "10px"
                                        }
                                    ],
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_8__.FontAwesomeIcon, {
                                        icon: _fortawesome_free_brands_svg_icons__WEBPACK_IMPORTED_MODULE_9__.faTiktok,
                                        fontSize: 20,
                                        size: "lg",
                                        color: "white"
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderTop);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4623:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1991);
/* harmony import */ var _Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9058);
/* harmony import */ var _NavBAr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(77);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Footer__WEBPACK_IMPORTED_MODULE_2__, _Header__WEBPACK_IMPORTED_MODULE_3__]);
([_Footer__WEBPACK_IMPORTED_MODULE_2__, _Header__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function Layout({ children }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavBAr__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
                ]
            }),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Footer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 77:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ Components_NavBAr)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/styles/style.module.css
var style_module = __webpack_require__(7262);
var style_module_default = /*#__PURE__*/__webpack_require__.n(style_module);
;// CONCATENATED MODULE: ./src/assets/images/logo.webp
/* harmony default export */ const logo = ({"src":"/_next/static/media/logo.395bb741.webp","height":512,"width":512,"blurDataURL":"data:image/webp;base64,UklGRqwAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAAAiN19ePCgAIxv/////ICo3/+f7++f+R1//+///+/9vX//7///7/24//+f7++f+TCsj/////ywwACpHb25MMAABWUDggRAAAAPABAJ0BKggACAACQDgllALsAR6CWC8pkAD+/J4PzfO6/ZMHcRJzqRcRjyE4cayL7cjLSj22e79xyrfSQYYDnPFH9AAA","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "@mui/icons-material/KeyboardArrowDown"
var KeyboardArrowDown_ = __webpack_require__(4845);
var KeyboardArrowDown_default = /*#__PURE__*/__webpack_require__.n(KeyboardArrowDown_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "@mui/material/AppBar"
var AppBar_ = __webpack_require__(3882);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);
// EXTERNAL MODULE: external "@mui/icons-material/Menu"
var Menu_ = __webpack_require__(3365);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/Cancel"
var Cancel_ = __webpack_require__(3733);
var Cancel_default = /*#__PURE__*/__webpack_require__.n(Cancel_);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/Components/NavBAr.jsx













function NavBAr() {
    const style = {
        navBar: {
            width: "100%",
            display: {
                lg: "flex",
                xs: "none"
            },
            flexBasis: "100%",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center"
        },
        dropDowmBox: {
            color: "white",
            backgroundColor: "#2296E6",
            padding: "1rem",
            marginLeft: "31rem",
            borderRadius: "1rem",
            width: "200px",
            position: "absolute",
            zIndex: "99",
            marginTop: "-2rem",
            display: "none"
        },
        text: {
            color: "white",
            textTransform: "capitalize",
            fontSize: "1.3rem",
            fontWeight: 600,
            padding: "0px",
            ":hover": {
                color: "#393738",
                textDecoration: "underline",
                transition: "ease all 0.8s"
            }
        },
        container: {
            maxWidth: {
                lg: "1500px",
                md: "1000px"
            }
        },
        smallAppBar: {
            display: {
                lg: "none",
                xs: "flex"
            }
        },
        appBars: {
            paddingY: "1rem"
        },
        appStyle: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexDirection: "row",
            width: "100%"
        },
        item: {
            color: "white",
            fontSize: "1rem",
            padding: "1rem"
        },
        listItems: {
            width: "100%"
        }
    };
    const [active, setActive] = (0,external_react_.useState)(false);
    const [isHoverDropdown, setIsHoverDropdown] = (0,external_react_.useState)(false);
    const handleMouseEnter = ()=>{
        setActive(true);
    };
    const handleMouseLeave = ()=>{
        setTimeout(()=>{
            if (!isHoverDropdown) setActive(false);
            else setActive(true);
        }, 1000);
    };
    const DropDownHandler = ()=>{
        if (active) {
            setActive(false);
        } else {
            setActive(true);
        }
    };
    const text = {
        color: "white",
        textTransform: "capitalize",
        fontSize: "1.3rem",
        fontWeight: 600,
        padding: 0
    };
    const [open, setOpen] = (0,external_react_.useState)(false);
    const openMenu = ()=>{
        if (open) {
            setOpen(false);
        } else {
            setOpen(true);
        }
    };
    const smallApp = [
        {
            link: "/",
            text: "HOME"
        },
        {
            link: "/about",
            text: "ABOUT US"
        },
        {
            link: "/",
            text: "SERVICE"
        },
        {
            link: "/our-work",
            text: "OUR WORK"
        },
        {
            link: "/blogs",
            text: "BLOGS"
        },
        {
            link: "/contact",
            text: "CONTACT US"
        },
        {
            link: "/get-a-quote",
            text: "GET A QOUTE"
        }
    ];
    const [showDropdown, setShowDropdown] = (0,external_react_.useState)(false);
    const toggleDropdown = ()=>{
        setShowDropdown(!showDropdown);
    };
    const router = (0,router_.useRouter)();
    const openServicePage = ()=>{
        router.push("/services");
    };
    const handleDoubleClick = ()=>{
        router.push("/services");
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                bgcolor: "#2296E6",
                color: "white",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Container, {
                    sx: style.container,
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                            sx: style.navBar,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                className: (style_module_default()).ul,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                                        className: (style_module_default()).boxStyle,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        children: "Home"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/about",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        children: "About Us"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                className: (style_module_default()).lis,
                                                onClick: openServicePage,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        onClick: DropDownHandler,
                                                        children: "Services"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx((KeyboardArrowDown_default()), {}),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                                                        className: (style_module_default()).dropDowmBox,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemButton, {
                                                                className: (style_module_default()).size,
                                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                    href: "/commercial-services",
                                                                    style: {
                                                                        textDecoration: "none",
                                                                        color: "inherit"
                                                                    },
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemText, {
                                                                        primary: "Commercial Service",
                                                                        sx: {
                                                                            ":hover": {
                                                                                color: "black",
                                                                                transition: "all ease 0.5s"
                                                                            }
                                                                        }
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("hr", {}),
                                                            /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemButton, {
                                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                    href: "/residential-services",
                                                                    style: {
                                                                        textDecoration: "none",
                                                                        color: "inherit"
                                                                    },
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemText, {
                                                                        primary: "Residential Service",
                                                                        className: (style_module_default()).size,
                                                                        sx: {
                                                                            ":hover": {
                                                                                color: "black",
                                                                                transition: "all ease 0.5s"
                                                                            }
                                                                        }
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/merchandise",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        id: (style_module_default()).margin,
                                                        children: "Merchandise"
                                                    })
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        className: (style_module_default()).liImage,
                                        id: (style_module_default()).margin,
                                        children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                            src: logo,
                                            alt: "logo",
                                            className: (style_module_default()).image,
                                            loading: "eager",
                                            fill: false
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                                        className: (style_module_default()).boxStyle,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/our-work",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        children: "Our Work"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/blogs",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        children: "Blogs"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/contact",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        children: "Contact Us"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                className: (style_module_default()).li,
                                                children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/get-a-quote",
                                                    style: {
                                                        textDecoration: "none"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                        sx: style.text,
                                                        children: "Get A Qoute"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                            sx: style.smallAppBar,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((AppBar_default()), {
                                position: "static",
                                sx: style.appBars,
                                bgcolor: "#2296E6",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                                        sx: style.appStyle,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                src: logo,
                                                width: 100,
                                                height: 100
                                            }),
                                            !open && /*#__PURE__*/ jsx_runtime.jsx((Menu_default()), {
                                                sx: {
                                                    fontSize: "2rem"
                                                },
                                                onClick: openMenu
                                            }),
                                            open && /*#__PURE__*/ jsx_runtime.jsx((Cancel_default()), {
                                                sx: {
                                                    fontSize: "2rem"
                                                },
                                                onClick: openMenu
                                            })
                                        ]
                                    }),
                                    open && /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                                        sx: style.listItems,
                                        children: smallApp.map((data)=>{
                                            return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
                                                children: data.text === "SERVICE" ? /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                    onDoubleClick: handleDoubleClick,
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                                        sx: style.item,
                                                                        onClick: toggleDropdown,
                                                                        children: data.text
                                                                    })
                                                                }),
                                                                showDropdown && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                                            sx: style.item,
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                href: "/commercial-services",
                                                                                style: {
                                                                                    textDecoration: "none",
                                                                                    listStyle: "none",
                                                                                    color: "white"
                                                                                },
                                                                                children: "COMMERCIAL SERVICE"
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                                            sx: style.item,
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                                href: "/residential-services",
                                                                                style: {
                                                                                    textDecoration: "none",
                                                                                    listStyle: "none",
                                                                                    color: "white"
                                                                                },
                                                                                children: "RESIDENTIAL SERVICE"
                                                                            })
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("hr", {})
                                                    ]
                                                }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                            sx: style.item,
                                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                                href: data.link,
                                                                style: {
                                                                    textDecoration: "none",
                                                                    listStyle: "none",
                                                                    color: "white"
                                                                },
                                                                children: data.text
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("hr", {})
                                                    ]
                                                })
                                            });
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            active && /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                sx: style.dropDowmBox,
                onMouseEnter: ()=>setIsHoverDropdown(true),
                onMouseLeave: ()=>{
                    setIsHoverDropdown(false);
                    setActive(false);
                },
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemButton, {
                        className: (style_module_default()).size,
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/commercial-services",
                            style: {
                                textDecoration: "none",
                                color: "inherit"
                            },
                            children: /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemText, {
                                primary: "Commercial Service",
                                sx: {
                                    ":hover": {
                                        color: "black",
                                        transition: "all ease 0.5s"
                                    }
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("hr", {}),
                    /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemButton, {
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/residential-services",
                            style: {
                                textDecoration: "none",
                                color: "inherit"
                            },
                            children: /*#__PURE__*/ jsx_runtime.jsx(material_.ListItemText, {
                                primary: "Residential Service",
                                className: (style_module_default()).size,
                                sx: {
                                    ":hover": {
                                        color: "black",
                                        transition: "all ease 0.5s"
                                    }
                                }
                            })
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const Components_NavBAr = (NavBAr);


/***/ })

};
;