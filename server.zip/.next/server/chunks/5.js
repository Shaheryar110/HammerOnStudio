"use strict";
exports.id = 5;
exports.ids = [5];
exports.modules = {

/***/ 7005:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ Home_Testimonials)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./src/assets/images/shape.webp
/* harmony default export */ const shape = ({"src":"/_next/static/media/shape.ec206524.webp","height":2825,"width":5744,"blurDataURL":"data:image/webp;base64,UklGRiQAAABXRUJQVlA4IBgAAAAwAQCdASoIAAQAAkA4JaQAA3AA/vgfgAA=","blurWidth":8,"blurHeight":4});
// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
// EXTERNAL MODULE: external "react-responsive-carousel"
var external_react_responsive_carousel_ = __webpack_require__(4508);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/assets/images/shape35.webp
/* harmony default export */ const shape35 = ({"src":"/_next/static/media/shape35.7aebe381.webp","height":76,"width":76,"blurDataURL":"data:image/webp;base64,UklGRpgAAABXRUJQVlA4WAoAAAAQAAAABwAABwAAQUxQSEEAAAAAADyYyOTt23BT/////////tH/+f3++/+o8P////3/2g7v/////f89ANL/+/z/zwACWf///P90AAQAZOn/twgAAQBWUDggMAAAALABAJ0BKggACAACQDgloAJ0ugAEMAAA/ulpH/hWs9bo1B//c4H/c4H/c4H8SAAAAA==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/assets/images/shape36.webp
/* harmony default export */ const shape36 = ({"src":"/_next/static/media/shape36.53608201.webp","height":59,"width":64,"blurDataURL":"data:image/webp;base64,UklGRlQAAABXRUJQVlA4WAoAAAAQAAAABwAABgAAQUxQSBYAAAABD6AQQAAUNBERC4FAsnqci0X0Pw4NVlA4IBgAAAAwAQCdASoIAAcAAkA4JaQAA3AA/vucwAA=","blurWidth":8,"blurHeight":7});
;// CONCATENATED MODULE: ./src/Components/Home/Testimonials.jsx




 // requires a loader



// import shape34 from "../../assets/images/shape34.webp";


function Testimonials() {
    const style = {
        main: {
            background: "rgb(255,255,255)",
            background: {
                lg: "linear-gradient(90deg, rgba(255,255,255,1) 51%, rgba(36,36,36,1) 51%)",
                sm: "white"
            },
            marginY: "7rem",
            position: "relative",
            zIndex: "2"
        },
        sliderCard: {
            padding: "1.5rem",
            width: "90%",
            height: "300px",
            boxShadow: "2px 4px 13px 3px rgba(0,0,0,0.3)",
            backgroundColor: "white",
            marginX: "2rem",
            marginY: "1rem"
        },
        content: {
            color: "grey",
            fontSize: "1.1rem",
            marginTop: "1rem"
        },
        iconAligns: {
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "flex-start"
        },
        carBox: {
            marginTop: "4rem",
            display: {
                lg: "block",
                xs: "none"
            }
        },
        carBox1: {
            marginTop: "5rem",
            marginLeft: {
                lg: "10rem",
                xs: "2rem"
            },
            zIndex: "99"
        },
        h4: {
            color: {
                lg: "#fff",
                sm: "black"
            },
            fontSize: "14px",
            fontWeight: 700,
            marginBottom: "10px",
            letterSpacing: "1px",
            fontFamily: "Inter, sans-serif",
            position: "relative",
            paddingLeft: "30px",
            lineHeight: "21px",
            "&::before": {
                content: '""',
                height: "3px",
                width: "21px",
                backgroundColor: "#2871ae",
                position: "absolute",
                top: "9px",
                left: 0
            }
        },
        h3: {
            fontFamily: "Inter, sans-serif",
            fontSize: "30px",
            lineHeight: "46px",
            fontWeight: 800,
            fontStyle: "normal",
            color: {
                lg: "#fff",
                sm: "black"
            },
            position: "relative",
            zIndex: "2"
        },
        imgBack: {
            position: "absolute",
            right: 0,
            top: "-2rem",
            height: "485px",
            display: {
                lg: "block",
                xs: "none"
            }
        }
    };
    const reviews = [
        " “We hired Hammer-On Studios to get our home’s flooring done. Their team is highly professional and has the right tools, and hired adequate techniques to get the job. We are extremely satisfied with their services and are soon going to call them for our home’s paint job.”",
        "“Our business had been looking for a contractor that can provide us with roofing services for quite a long time. One of our partners recommended us Hammer-On Studios and we are more than happy with the services they provided. Definitely going to work with them in the future.” ",
        "“The entire crew of Hammer-On Studios was amazing. They replaced all of our sliding doors and windows and added a slider where there was previously a door. From start to finish, they did their job perfectly. Overall the job turned out perfect. We love our new windows and sliding doors!” "
    ];
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
            sx: style.main,
            children: [
                /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                    sx: style.imgBack,
                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                        src: shape,
                        fill: false,
                        style: {
                            width: "100%",
                            height: "100%"
                        }
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Grid, {
                    container: true,
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx(material_.Grid, {
                            item: true,
                            lg: 6,
                            children: /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                                sx: style.carBox,
                                children: /*#__PURE__*/ jsx_runtime.jsx(external_react_responsive_carousel_.Carousel, {
                                    autoPlay: true,
                                    showArrows: false,
                                    showIndicators: false,
                                    centerMode: true,
                                    centerSlidePercentage: 55,
                                    showStatus: false,
                                    interval: 2000,
                                    infiniteLoop: true,
                                    showThumbs: false,
                                    width: "100%",
                                    children: reviews.map((data, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                                            sx: style.sliderCard,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                    src: shape35,
                                                    width: 100,
                                                    height: 100,
                                                    style: {
                                                        width: "60px",
                                                        height: "60px"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                    src: shape36,
                                                    width: 100,
                                                    height: 100,
                                                    style: {
                                                        width: "60px",
                                                        height: "60px"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                                    sx: style.content,
                                                    children: data
                                                })
                                            ]
                                        }, index))
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx(material_.Grid, {
                            item: true,
                            lg: 6,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                                sx: style.carBox1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                        variant: "h4",
                                        sx: style.h4,
                                        children: "OUR TESTIMONIAL"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                        variant: "h3",
                                        sx: style.h3,
                                        children: "What Our Clients Say About Us"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                        sx: {
                                            color: {
                                                lg: "white",
                                                sm: "black"
                                            },
                                            width: "90%",
                                            marginY: "1rem",
                                            position: "relative",
                                            zIndex: "2"
                                        },
                                        children: "We consider our renovation projects not just a job; it’s our opportunity to bring a lasting imperative change to clients’ lives. These reviews of our corporate and homeowners warm our hearts as a team and spur us on to keep doing what we do the best."
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime.jsx(material_.Box, {
                    sx: {
                        display: {
                            lg: "none",
                            sm: "block"
                        }
                    },
                    children: reviews.map((data, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)(material_.Box, {
                            sx: style.sliderCard,
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: shape35,
                                    width: 100,
                                    height: 100,
                                    style: {
                                        width: "60px",
                                        height: "60px"
                                    }
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                    src: shape36,
                                    width: 100,
                                    height: 100,
                                    style: {
                                        width: "60px",
                                        height: "60px"
                                    }
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx(material_.Typography, {
                                    sx: style.content,
                                    children: data
                                })
                            ]
                        }, index))
                })
            ]
        })
    });
}
/* harmony default export */ const Home_Testimonials = (Testimonials);


/***/ })

};
;