"use strict";
exports.id = 549;
exports.ids = [549];
exports.modules = {

/***/ 8680:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/card2.90dcadaf.webp","height":350,"width":520,"blurDataURL":"data:image/webp;base64,UklGRkwAAABXRUJQVlA4IEAAAACwAQCdASoIAAUAAkA4JQBOgB5vWbQAAP62du7GG9SP57c5IbZKYXNsEwQNpBvtrP9WQDwblALiPLulhC8uAAAA","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 1607:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cardsvg1.bbb293a6.webp","height":164,"width":475,"blurDataURL":"data:image/webp;base64,UklGRnIAAABXRUJQVlA4WAoAAAAQAAAABwAAAgAAQUxQSBkAAAAAmPNjB1eb0Nn///Lr//////39///9/P3+AFZQOCAyAAAA0AEAnQEqCAADAAJAOCWcAuwBH231BgAA/vZ37xTyDcssf20iMKjRZ0hUT8MCCynLAAA=","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 1755:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cardsvg2.ef47263c.webp","height":164,"width":475,"blurDataURL":"data:image/webp;base64,UklGRnIAAABXRUJQVlA4WAoAAAAQAAAABwAAAgAAQUxQSBkAAAAAmPNjB1eb0Nn///Lr//////39///9/P3+AFZQOCAyAAAA0AEAnQEqCAADAAJAOCWcAuwBH231BgAA/vZ37xTyDcssf4JXpxkRJSb3uHy+P/J4QAA=","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 7639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/sbg.69f2b2cd.webp","height":994,"width":1920,"blurDataURL":"data:image/webp;base64,UklGRlYAAABXRUJQVlA4WAoAAAAQAAAABwAAAwAAQUxQSBgAAAABFzABERGGgrZR4Ny9DpAGEojof3S6fwBWUDggGAAAADABAJ0BKggABAACQDglpAADcAD++uKAAA==","blurWidth":8,"blurHeight":4});

/***/ }),

/***/ 5623:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/services01.a12063b9.webp","height":350,"width":520,"blurDataURL":"data:image/webp;base64,UklGRkwAAABXRUJQVlA4IEAAAADwAQCdASoIAAUAAkA4JYgCdLoAArdO6pAA/o4G7Nyz+G2rmC0exbAF/5txqYP0pHhCaKr7rvIArmNUu64x0kAA","blurWidth":8,"blurHeight":5});

/***/ }),

/***/ 3549:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_font_google_target_css_path_src_Components_Home_WhatWeDo_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_variableName_inter___WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3129);
/* harmony import */ var next_font_google_target_css_path_src_Components_Home_WhatWeDo_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_variableName_inter___WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_Components_Home_WhatWeDo_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_variableName_inter___WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_style_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7262);
/* harmony import */ var _styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _assets_images_sbg_webp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7639);
/* harmony import */ var _assets_images_services01_webp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5623);
/* harmony import */ var _mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5048);
/* harmony import */ var _mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_images_cardsvg1_webp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1607);
/* harmony import */ var _assets_images_cardsvg2_webp__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1755);
/* harmony import */ var _assets_images_card2_webp__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8680);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_10__]);
framer_motion__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];














function WhatWeDo() {
    const style = {
        container: {
            maxWidth: {
                xl: "1300px"
            }
        },
        bgMain: {
            backgroundColor: "#191818",
            backgroundImage: `url(${_assets_images_sbg_webp__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.src})`,
            backgroundPosition: "bottom center",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
            padding: "6rem 0"
        },
        ic: {
            color: "#393738",
            fontSize: "1rem"
        },
        h4: {
            color: "#fff",
            fontSize: "14px",
            fontWeight: 700,
            marginBottom: "10px",
            letterSpacing: "1px",
            fontFamily: "Inter, sans-serif",
            position: "relative",
            paddingLeft: "30px",
            lineHeight: "21px",
            "&::before": {
                content: '""',
                height: "3px",
                width: "21px",
                backgroundColor: "#2871ae",
                position: "absolute",
                top: "9px",
                left: 0
            }
        },
        h3: {
            fontSize: "36px",
            lineHeight: "46px",
            fontWeight: 1000,
            margin: "0px 0px 20px",
            color: "#fff"
        },
        par: {
            fontSize: "17px",
            fontWeight: 400,
            lineHeight: "1.7",
            fontFamily: "Roboto, sans-serif",
            margin: "30px 0",
            color: "white"
        },
        hThree: {
            fontWeight: 700,
            marginBottom: "12px",
            fontSize: "24px",
            color: "#393738",
            ":hover": {
                color: "#2871AE"
            }
        },
        paragraph: {
            marginTop: 0,
            color: "#7a7a7a",
            fontSize: "15px",
            marginBottom: 0
        },
        btn: {
            color: "#000",
            marginTop: "13px",
            display: "inherit",
            border: "none",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            backgroundColor: "white",
            fontWeight: "600",
            ":hover": {
                color: "red"
            }
        },
        article: {
            position: "relative"
        },
        svg: {
            width: "100%",
            height: "40%",
            position: "relative",
            left: "-25px",
            top: "-65px"
        },
        artice: {
            padding: "0px 25px 25px 25px",
            position: "relative",
            transition: "all 0.5s ease",
            height: {
                md: "120px",
                sm: "130px",
                xs: "130px"
            },
            marginTop: "-4rem"
        }
    };
    const [hover, setHover] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const onMouseEnter = ()=>{
        setHover(true);
    };
    const onMouseLeave = ()=>{
        setHover(false);
    };
    const [hover1, setHover1] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const onMouseEnter1 = ()=>{
        setHover1(true);
    };
    const onMouseLeave1 = ()=>{
        setHover1(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
            className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().bgMain),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Container, {
                sx: style.container,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        container: true,
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 6,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().headings),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            variant: "h4",
                                            sx: style.h4,
                                            children: "WHAT WE DO"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            variant: "h3",
                                            sx: style.h3,
                                            className: (next_font_google_target_css_path_src_Components_Home_WhatWeDo_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_variableName_inter___WEBPACK_IMPORTED_MODULE_12___default().className),
                                            children: "At Hammer-On Studios, we specialize in offering residential and building repair and renovation services."
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 6,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        sx: style.par,
                                        children: "We provide facility renovation services that are designed to utilize your location in the best possible way, helping you improve the aesthetics, functionality, and value of your property."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        sx: style.par,
                                        children: "From simple remodeling to adding an extension, Hammer-On Studios has adequate skills and knowledge to deliver all your projects on time and within budget."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        container: true,
                        className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().card),
                        columnSpacing: 2,
                        justifyContent: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().border)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 5,
                                md: 6,
                                sm: 7,
                                xs: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().cardInfo),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("figure", {
                                            className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().fig),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                src: _assets_images_services01_webp__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                                fill: false,
                                                style: {
                                                    width: "100%"
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                            sx: {
                                                position: "relative"
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.svg,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    src: _assets_images_cardsvg1_webp__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                                    fill: false,
                                                    style: {
                                                        width: "100%",
                                                        height: "100%"
                                                    }
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                            animate: {
                                                y: hover1 ? -40 : 0
                                            },
                                            transition: {
                                                duration: 0.5
                                            },
                                            onMouseEnter: onMouseEnter1,
                                            onMouseLeave: onMouseLeave1,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.artice,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                        variant: "h3",
                                                        sx: style.hThree,
                                                        children: "Commercial Services"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                        sx: style.paragraph,
                                                        children: "Hammer-On Studios supports commercial locations with top-quality renovation services tailored to our clients’ eclectic needs. From breweries and restaurants to…"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                        sx: style.btn,
                                                        children: [
                                                            "Read More ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                sx: style.ic
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                lg: 5,
                                md: 6,
                                sm: 7,
                                xs: 12,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().cardInfo),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("figure", {
                                            className: (_styles_style_module_css__WEBPACK_IMPORTED_MODULE_11___default().fig),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                src: _assets_images_card2_webp__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                                                fill: false,
                                                style: {
                                                    width: "100%"
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                            sx: {
                                                position: "relative"
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.svg,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    src: _assets_images_cardsvg2_webp__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                                                    fill: false,
                                                    style: {
                                                        width: "100%",
                                                        height: "100%"
                                                    }
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                            animate: {
                                                y: hover ? -40 : 0
                                            },
                                            transition: {
                                                duration: 0.5
                                            },
                                            onMouseEnter: onMouseEnter,
                                            onMouseLeave: onMouseLeave,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                                sx: style.artice,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                        variant: "h3",
                                                        sx: style.hThree,
                                                        children: "Residential Services"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                        sx: style.paragraph,
                                                        children: "Hammer-On Studios supports commercial locations with top-quality renovation services tailored to our clients’ eclectic needs. From breweries and restaurants to…"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                                        sx: style.btn,
                                                        children: [
                                                            "Read More ",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardDoubleArrowRight__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                sx: style.ic
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhatWeDo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;