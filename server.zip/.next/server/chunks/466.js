exports.id = 466;
exports.ids = [466];
exports.modules = {

/***/ 1617:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_607230', '__Inter_Fallback_607230'","fontStyle":"normal"},
	"className": "__className_607230"
};


/***/ }),

/***/ 8597:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_font_google_target_css_path_src_Components_Commons_FourHoverCards_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1617);
/* harmony import */ var next_font_google_target_css_path_src_Components_Commons_FourHoverCards_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_Components_Commons_FourHoverCards_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5127);
/* harmony import */ var _styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Home_AnimatedCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4697);







function FourHoverCards({ background }) {
    const style = {
        readyCard: {
            paddingY: "6rem"
        },
        card: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: "100%"
        },
        static: {
            textAlign: "center",
            marginY: "3rem"
        },
        textHead: {
            fontSize: "36px",
            fontWeight: 800,
            lineHeight: "46px",
            color: "#393738"
        },
        slogan: {
            color: "#646464",
            fontSize: "1rem"
        },
        cardHeading: {
            fontSize: "38px",
            fontWeight: 800,
            lineHeight: "46px",
            color: "#393738"
        },
        cardSectionTop: {
            marginY: "6rem"
        },
        main: {
            width: "100%",
            height: "100%",
            backgroundColor: background || "white"
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
        sx: style.main,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Container, {
            className: (_styles_responsive_module_css__WEBPACK_IMPORTED_MODULE_4___default().container),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Box, {
                sx: style.cardSectionTop,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                        container: true,
                        columnSpacing: 3,
                        sx: {
                            justifyContent: "space-between",
                            marginY: "2rem"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    variant: "h3",
                                    sx: style.cardHeading,
                                    className: (next_font_google_target_css_path_src_Components_Commons_FourHoverCards_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_5___default().className),
                                    children: "Leading Way In Roofing & Home Repair Construction!"
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                item: true,
                                lg: 6,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        sx: style.slogan,
                                        className: (next_font_google_target_css_path_src_Components_Commons_FourHoverCards_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_5___default().className),
                                        children: "At Hammer-On Studios, we specialize in delivering high-end commercial and home renovation services in New York. We achieve this by utilizing our skills to deliver you a professional remodeling service that is focused on quality in every way."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: (next_font_google_target_css_path_src_Components_Commons_FourHoverCards_jsx_import_Inter_arguments_subsets_latin_weight_400_500_700_900_variableName_inter___WEBPACK_IMPORTED_MODULE_5___default().className),
                                        style: {
                                            paddingLeft: "2rem"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            style: {
                                                color: "#393738",
                                                fontSize: "1rem",
                                                marginTop: "1rem",
                                                fontFamily: "inherit"
                                            },
                                            children: "3000+ successfully completed projects"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Home_AnimatedCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                ]
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FourHoverCards);


/***/ }),

/***/ 3559:
/***/ (() => {



/***/ })

};
;