import Stripe from "../Commons/Stripe";

function StripSection() {
  return (
    <>
      <Stripe heading="ABOUT US" />
    </>
  );
}

export default StripSection;
