import TermsAndCondition from "@/Components/Terms/TermsAndCondition";
import React from "react";

function terms() {
  return <TermsAndCondition />;
}

export default terms;
