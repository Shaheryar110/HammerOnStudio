import PrivacyPolicy from "@/Components/privacy/PrivacyPolicy";
import React from "react";

function privacy() {
  return <PrivacyPolicy />;
}

export default privacy;
