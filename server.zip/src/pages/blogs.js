import Blogs from "@/Components/Blogs/Blogs";
import Layout from "@/Components/Layout";
import React from "react";

function blogs() {
  return (
    <Layout>
      <Blogs />
    </Layout>
  );
}

export default blogs;
