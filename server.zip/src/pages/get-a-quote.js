import GetAQoute from "@/Components/Get-a-Qoute/GetAQoute";
import Layout from "@/Components/Layout";
import React from "react";

function getaqoute() {
  return (
    <Layout>
      <GetAQoute />
    </Layout>
  );
}

export default getaqoute;
